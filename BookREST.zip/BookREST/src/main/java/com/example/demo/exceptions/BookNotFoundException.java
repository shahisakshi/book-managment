package com.example.demo.exceptions;

public class BookNotFoundException extends RuntimeException {

}