package com.example.demo.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.User;
import com.example.demo.repositories.UserRepository;

@RestController
@RequestMapping("/")
public class UserController {
	@Autowired
	UserRepository userRepository;
	
	@PostMapping("/register")
	public User register(@RequestBody User u) {
		return userRepository.save(u);
	}
	
	@GetMapping("/login")
	public boolean login(@RequestBody User u) {
		String e = u.getEmail();
		User userdata = userRepository.findByEmail(e);
			if(u.getPassword()==userdata.getPassword() && u.getEmail()==userdata.getEmail()) {
				return true;
			}
			return false;	
	}
}
