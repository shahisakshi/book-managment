package com.example.demo.model;

import java.sql.Date;

import jakarta.persistence.*;

@Entity
@Table(name="bookdata")
public class Book {
	@Id
	@Column(name="bookid")
	private int bookid;
	@Column(name="title")
	private String title;
	@Column(name="author")
	private String author;
	@Column(name="date")
	private Date date;
	@Column(name="isbn")
	private String isnb;
	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getIsnb() {
		return isnb;
	}
	public void setIsnb(String isnb) {
		this.isnb = isnb;
	}
	
}
