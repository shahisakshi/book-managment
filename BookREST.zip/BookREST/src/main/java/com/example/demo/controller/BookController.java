package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import com.example.demo.model.Book;
import com.example.demo.repositories.BookRepository;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/books")
@CrossOrigin("http://localhost:4200/")
public class BookController {
	@Autowired
	BookRepository bookRepository;
	
	@GetMapping("/getBooks")
	public List<Book> getBooks() {
		return bookRepository.findAll();
	}
	
	@PostMapping("/addBooks")
	public Book addBooks(@RequestBody Book b) {
		return bookRepository.save(b);
	}
	
	//by id
	@GetMapping("/getBooks/{id}")
	public Book getBooks(@PathVariable("id") int bookid) {
			Optional<Book> bookdata = bookRepository.findById(bookid);
			if(bookdata.isPresent()) {
				return bookdata.get();
			} else {
				return null;
			}
		}
	
	//by title
	@GetMapping("/getBooksByTitle/{title}")
	public Book getBooksByTitle(@PathVariable("title") String title) {
		Optional<Book> bookdata = bookRepository.findByTitle(title);
		if(bookdata.isPresent()) {
			return bookdata.get();
		} else {
			return null;
		}
	}
	
	
	//by title and name
	@GetMapping("/getByIdAndTitle/{id}/{title}")
	public Book getByIdAndTitle(@PathVariable("id") int id,@PathVariable("title") String title) {
		return bookRepository.findByBookidAndTitle(id,title);
				
	}

	@PutMapping("/updateBook/{id}") 
	public Book updateBook(@PathVariable("id") int id,@RequestBody Book b ) {
		Book updatedBook = null;
		Optional<Book> bookdata = bookRepository.findById(id);
		if(bookdata.isPresent()) {
			updatedBook = bookdata.get();
			updatedBook.setAuthor(b.getAuthor());
			updatedBook.setTitle(b.getTitle());
			updatedBook.setDate(b.getDate());
			updatedBook.setIsnb(b.getIsnb());
		} 
		
		return bookRepository.save(b);
	}
	
	@DeleteMapping("/deleteBook/{id}")
	public void deleteBook(@PathVariable("id") int id) {
		 bookRepository.deleteById(id);
	}
	
}
